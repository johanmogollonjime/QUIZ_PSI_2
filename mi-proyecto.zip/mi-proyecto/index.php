<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    h1{
        font-size: 180px;
        color: red;
    }
    a{
        color: black;
        font-size: 40px;
    }
</style>
<body>
    <h1>eimard care monda </h1>
     <a href="https://preview.redd.it/cris-valencia-v0-fg9davgrxnbd1.jpg?width=640&crop=smart&auto=webp&s=549ebe1729291f117772c276e87420a4d676a495" target="_blank">
        haz clic y conoce a eimard
     </a>
</body>
</html>